# NoSQL FastAPI Service

## Установка

```bash
python -m venv venv
source venv/bin/activate  # Windows: venv\Scripts\activate
pip install -r requirements.txt
http://localhost:8000/docs

