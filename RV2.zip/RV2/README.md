 uvicorn app.main:app --host 127.0.0.1 --port 24110 --reload
Для запуска проекта 
 код постгрес 0413120