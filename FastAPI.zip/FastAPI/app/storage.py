from typing import Dict
from app.models import UserResponseTo

users: Dict[str, UserResponseTo] = {}
# Это простой словарь, где будут храниться пользователи
users = {}
